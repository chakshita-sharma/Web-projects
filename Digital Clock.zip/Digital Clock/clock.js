function update()
 {
   var dateTime = new Date();
   var Days =["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
   var months = ["January","February","March","April","May","June","July","August","September", "October","November","December"];
    var Day= dateTime.getDay();
    var month = dateTime.getMonth();
    var year =dateTime.getFullYear();
    var date =dateTime.getDate();
    var DayMonth = Days[Day];
    var knowdates = date + " " + months[month] +" "+ year;
    document.getElementById("date").innerHTML = DayMonth;
    document.getElementById("DAY").innerHTML = knowdates;
  
 }

 function showTime(){
  var time = new Date;
 var hour= time.getHours();
 var min= time.getMinutes();
 var sec= time.getSeconds();
 session ="AM";
 if(hour <= 12){
  session ="AM";
 }
 else{
  session="PM";
 }
 
 if(hour<10){
  hour ="0"+hour;
 }
 
 if(min<10){
  min ="0"+min;
 }
 if(sec<10){
  sec ="0"+sec;
 }

 let currentTime = hour + ":"+ min + ":"+ sec+ " "+ session;
 document.getElementById("clock").innerHTML= currentTime;
update();
 }
 
showTime();


setInterval(showTime,1000);